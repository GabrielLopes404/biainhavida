import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, MapPin, Clock, Briefcase } from "lucide-react";
import { motion } from "framer-motion";

export default function CarreirasPage() {
  const [, setLocation] = useLocation();

  const positions = [
    {
      title: "Desenvolvedor Full Stack Senior",
      department: "Engenharia",
      location: "Remoto",
      type: "Tempo Integral",
      description: "Buscamos um desenvolvedor experiente em React, Node.js e PostgreSQL."
    },
    {
      title: "Product Manager",
      department: "Produto",
      location: "São Paulo / Remoto",
      type: "Tempo Integral",
      description: "Lidere o desenvolvimento de novos recursos e melhore a experiência do usuário."
    },
    {
      title: "Customer Success Specialist",
      department: "Sucesso do Cliente",
      location: "Remoto",
      type: "Tempo Integral",
      description: "Ajude nossos clientes a alcançar seus objetivos com o LUCREI."
    }
  ];

  const benefits = [
    "💰 Salário compatível com o mercado",
    "🏠 Trabalho remoto ou híbrido",
    "🏖️ Férias flexíveis",
    "📚 Orçamento para educação",
    "🏥 Plano de saúde e dental",
    "💻 Setup de trabalho completo"
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-purple-400 bg-clip-text text-transparent">
            Carreiras no LUCREI
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Faça parte de um time que está transformando a gestão financeira
          </p>
        </motion.div>

        <Card className="mb-12">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-center">Benefícios</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className="flex items-center gap-3 p-4 rounded-lg bg-muted/50"
                >
                  <span className="text-lg">{benefit}</span>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        <h2 className="text-2xl font-bold mb-6">Vagas Abertas</h2>
        <div className="space-y-6">
          {positions.map((position, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold mb-2">{position.title}</h3>
                      <Badge variant="secondary">{position.department}</Badge>
                    </div>
                  </div>
                  <p className="text-muted-foreground mb-4">{position.description}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>{position.location}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{position.type}</span>
                    </div>
                  </div>
                  <Button 
                    onClick={() => setLocation("/contato")}
                    className="bg-gradient-to-r from-purple-600 to-purple-400"
                  >
                    Candidatar-se
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center mt-12"
        >
          <Card className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 border-purple-500/20">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4">Não encontrou a vaga ideal?</h2>
              <p className="text-muted-foreground mb-6">
                Envie seu currículo e entraremos em contato quando surgir uma oportunidade adequada
              </p>
              <Button 
                onClick={() => setLocation("/contato")}
                variant="outline"
              >
                Enviar Currículo
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
