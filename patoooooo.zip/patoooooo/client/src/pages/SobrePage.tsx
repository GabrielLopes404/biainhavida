import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Target, Heart, Users, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

export default function SobrePage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-purple-400 bg-clip-text text-transparent">
            Sobre o LUCREI
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Transformando a gestão financeira de empresas modernas
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card>
              <CardContent className="p-8">
                <Target className="h-12 w-12 text-purple-600 mb-4" />
                <h2 className="text-2xl font-bold mb-4">Nossa Missão</h2>
                <p className="text-muted-foreground">
                  Democratizar o acesso a ferramentas de gestão financeira profissionais, 
                  tornando a vida de empresários e gestores mais simples e produtiva através 
                  da tecnologia.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Card>
              <CardContent className="p-8">
                <Heart className="h-12 w-12 text-purple-600 mb-4" />
                <h2 className="text-2xl font-bold mb-4">Nossos Valores</h2>
                <p className="text-muted-foreground">
                  Transparência, segurança e inovação são os pilares que guiam cada decisão. 
                  Acreditamos em construir relações de longo prazo com nossos clientes baseadas 
                  em confiança mútua.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <Card>
            <CardContent className="p-6 text-center">
              <Users className="h-12 w-12 mx-auto mb-4 text-purple-600" />
              <h3 className="text-3xl font-bold mb-2">10.000+</h3>
              <p className="text-muted-foreground">Empresas confiam no LUCREI</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-12 w-12 mx-auto mb-4 text-purple-600" />
              <h3 className="text-3xl font-bold mb-2">R$ 1B+</h3>
              <p className="text-muted-foreground">Gerenciados mensalmente</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Heart className="h-12 w-12 mx-auto mb-4 text-purple-600" />
              <h3 className="text-3xl font-bold mb-2">98%</h3>
              <p className="text-muted-foreground">Índice de satisfação</p>
            </CardContent>
          </Card>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center"
        >
          <Card className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 border-purple-500/20">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-4">Faça parte dessa transformação</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Junte-se a milhares de empresas que já transformaram sua gestão financeira
              </p>
              <Button 
                size="lg"
                onClick={() => setLocation("/register")}
                className="bg-gradient-to-r from-purple-600 to-purple-400"
              >
                Começar Agora
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
