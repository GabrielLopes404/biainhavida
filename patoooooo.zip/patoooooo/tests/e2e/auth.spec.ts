import { test, expect } from '@playwright/test';

test.describe('Authentication Flow', () => {
  test('should complete full registration and login flow', async ({ page }) => {
    const timestamp = Date.now();
    const testEmail = `test${timestamp}@example.com`;
    const testPassword = 'Test!Pass123';

    // 1. Navigate to register page
    await page.goto('/register');
    await expect(page).toHaveURL(/.*register/);

    // 2. Fill registration form
    await page.fill('input[name="email"]', testEmail);
    await page.fill('input[name="password"]', testPassword);
    await page.fill('input[name="username"]', `testuser${timestamp}`);
    await page.fill('input[name="name"]', 'Test User');
    await page.fill('input[name="organizationName"]', 'Test Organization');

    // 3. Submit registration
    await page.click('button[type="submit"]');

    // 4. Should redirect to dashboard after auto-login
    await expect(page).toHaveURL(/.*dashboard/);

    // 5. Verify user is logged in
    await expect(page.locator('text=Test User')).toBeVisible();

    // 6. Logout
    await page.click('button:has-text("Logout")');
    await expect(page).toHaveURL(/.*login/);

    // 7. Login again with credentials
    await page.fill('input[name="email"]', testEmail);
    await page.fill('input[name="password"]', testPassword);
    await page.click('button[type="submit"]');

    // 8. Verify logged in
    await expect(page).toHaveURL(/.*dashboard/);
  });

  test('should show error with invalid credentials', async ({ page }) => {
    await page.goto('/login');

    await page.fill('input[name="email"]', 'nonexistent@example.com');
    await page.fill('input[name="password"]', 'WrongPass123!');
    await page.click('button[type="submit"]');

    // Should show error message
    await expect(page.locator('text=Invalid credentials')).toBeVisible();
  });

  test('should validate password strength on registration', async ({ page }) => {
    await page.goto('/register');

    await page.fill('input[name="email"]', 'test@example.com');
    await page.fill('input[name="password"]', 'weak'); // Weak password
    await page.fill('input[name="username"]', 'testuser');
    await page.fill('input[name="name"]', 'Test User');

    // Try to submit
    await page.click('button[type="submit"]');

    // Should show validation error
    await expect(page.locator('text=Password must')).toBeVisible();
  });
});

test.describe('Password Reset Flow', () => {
  test.skip('should complete password reset flow', async ({ page }) => {
    // This test requires email service to be configured
    await page.goto('/forgot-password');

    await page.fill('input[name="email"]', 'test@example.com');
    await page.click('button[type="submit"]');

    await expect(page.locator('text=reset email sent')).toBeVisible();
  });
});

test.describe('Mobile Responsiveness', () => {
  test('should have accessible tap targets on mobile', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 667 }); // iPhone SE

    await page.goto('/login');

    // Buttons should be at least 44px tall (iOS touch target guideline)
    const submitButton = page.locator('button[type="submit"]');
    const boundingBox = await submitButton.boundingBox();
    
    expect(boundingBox?.height).toBeGreaterThanOrEqual(44);
  });

  test('should not have horizontal scroll on mobile', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 667 });

    await page.goto('/dashboard');

    // Check for horizontal overflow
    const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    const clientWidth = await page.evaluate(() => document.documentElement.clientWidth);

    expect(scrollWidth).toBeLessThanOrEqual(clientWidth + 1); // +1 for rounding
  });
});
